.. include:: ../README.rst

.. toctree::
   :maxdepth: 2
   :hidden:

   /installation
   /guide
   /reference
   /recipes
   /algorithms
   /develop
   /changes
